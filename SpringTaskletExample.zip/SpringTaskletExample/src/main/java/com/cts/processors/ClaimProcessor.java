package com.cts.processors;

import org.springframework.batch.item.ItemProcessor;

import com.cts.model.Claim;

public class ClaimProcessor implements ItemProcessor<Claim, Claim> {

	public Claim process(Claim Claim) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Claim Object Received as" + Claim);
		return Claim;
	}

}
