package com.cts.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ClaimRowMapper implements RowMapper<Claim> {

	public Claim mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		Claim claim = new Claim();
		claim.setClaimId(rs.getInt("claimId"));
		claim.setDoc(rs.getString("doc"));
		claim.setAmount(rs.getInt("amount"));
		claim.setPolicyHolderName(rs.getString("policyHolderName"));
		return claim;
	}

}
