package com.cts.model;

import java.time.LocalDate;

public class Claim {
	
	private int claimId;
	private String doc;

	private int amount;
	private String policyHolderName;
	
	public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	
	public String getDoc() {
		return doc;
	}
	public void setDoc(String doc) {
		this.doc = doc;
	}
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getPolicyHolderName() {
		return policyHolderName;
	}
	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}
	
	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", doc=" + doc + ", amount=" + amount + ", policyHolderName="
				+ policyHolderName + "]";
	}
	
	
	

}
