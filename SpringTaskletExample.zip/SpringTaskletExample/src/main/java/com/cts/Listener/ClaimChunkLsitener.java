package com.cts.Listener;

import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;

public class ClaimChunkLsitener implements ChunkListener {

	public void afterChunk(ChunkContext arg0) {
		// TODO Auto-generated method stub
		System.out.println("After Chunk...."+arg0);
		
	}

	public void afterChunkError(ChunkContext arg0) {
		// TODO Auto-generated method stub
		System.out.println("error Chunk...."+arg0);
	}

	public void beforeChunk(ChunkContext arg0) {
		// TODO Auto-generated method stub
		System.out.println("Before Chunk...."+arg0);
	}

}
