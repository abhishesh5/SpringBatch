package com.cts.Listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class ClaimStepExecutionListener implements StepExecutionListener {

	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		System.out.println("*******After Step***********" + arg0);
		return ExitStatus.COMPLETED;
	}

	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		System.out.println("*******Before Step***********" + arg0);
	}

}
